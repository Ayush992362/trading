# Crypto Demo Trading Bot (Binance Spot Testnet) - no pandas version

Fake money only. Strategy: EMA crossover + RSI filter, long-only, with stop-loss/take-profit.
Uses only `ccxt` and `python-dotenv` (no pandas/numpy), so Windows Smart App Control won't block it.
Educational project, not financial advice.

## Setup (PowerShell, inside this folder)
    python -m venv venv
    venv\Scripts\activate
    python -m pip install -r requirements.txt
    copy .env.example .env
    notepad .env        # paste your testnet key + secret

Get free testnet keys: https://testnet.binance.vision (log in with GitHub -> Generate HMAC_SHA256 Key).
If you are in the US, set DATA_EXCHANGE=binanceus in .env.

## Run in this order
    python test_connection.py   # checks keys + shows demo balance
    python data.py              # downloads 2 years of real price history
    python backtest.py          # tests the strategy on that history (with fees)
    python bot.py               # starts the demo bot (Ctrl+C to stop)

Trades are saved in `trades.csv`, logs in `bot.log`. Edit settings in `config.py`.
