"""EMA crossover + RSI filter, written in plain Python (no pandas/numpy).
Candles are lists: [time_ms, open, high, low, close, volume]."""
import config


def ema(values, span):
    alpha = 2 / (span + 1)
    out = [values[0]]
    for v in values[1:]:
        out.append(alpha * v + (1 - alpha) * out[-1])
    return out


def rsi(closes, period):
    """Wilder-smoothed RSI. Returns a list (None for the first candle)."""
    alpha = 1 / period
    out = [None]
    avg_gain = avg_loss = None
    for i in range(1, len(closes)):
        delta = closes[i] - closes[i - 1]
        gain, loss = max(delta, 0.0), max(-delta, 0.0)
        if avg_gain is None:
            avg_gain, avg_loss = gain, loss
        else:
            avg_gain = alpha * gain + (1 - alpha) * avg_gain
            avg_loss = alpha * loss + (1 - alpha) * avg_loss
        if avg_loss == 0:
            out.append(100.0 if avg_gain > 0 else 50.0)
        else:
            out.append(100 - 100 / (1 + avg_gain / avg_loss))
    return out


def compute_signals(candles):
    """Returns (buy_flags, sell_flags) lists, one entry per candle.
    buy  = fast EMA crosses above slow EMA and RSI is not overbought
    sell = fast EMA crosses below slow EMA"""
    closes = [c[4] for c in candles]
    fast = ema(closes, config.FAST_EMA)
    slow = ema(closes, config.SLOW_EMA)
    rs = rsi(closes, config.RSI_PERIOD)

    buys, sells = [], []
    prev_above = False
    for i in range(len(closes)):
        above = fast[i] > slow[i]
        crossed_up = above and not prev_above
        crossed_down = (not above) and prev_above
        buys.append(bool(crossed_up and rs[i] is not None and rs[i] < config.RSI_MAX_ENTRY))
        sells.append(bool(crossed_down))
        prev_above = above
    return buys, sells


def latest_signal(candles):
    """Signal from the last CLOSED candle: 'buy', 'sell' or 'hold'."""
    buys, sells = compute_signals(candles)
    if buys[-1]:
        return "buy"
    if sells[-1]:
        return "sell"
    return "hold"
