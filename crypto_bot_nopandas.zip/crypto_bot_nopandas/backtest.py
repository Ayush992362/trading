"""Backtest the strategy on downloaded history, with fees + slippage.
The last 30% of the data is also reported separately as 'out-of-sample'."""
from datetime import datetime, timezone
import config
from data import csv_path, load_csv
from strategy import compute_signals


def run_backtest(candles):
    buys, sells = compute_signals(candles)
    cash, qty, entry = config.START_BALANCE, 0.0, 0.0
    trades, equity = [], []

    for i, (_, o, h, l, c, v) in enumerate(candles):
        if qty > 0:
            stop = entry * (1 - config.STOP_LOSS_PCT)
            tp = entry * (1 + config.TAKE_PROFIT_PCT)
            exit_price = None
            if l <= stop:
                exit_price = stop
            elif h >= tp:
                exit_price = tp
            elif sells[i]:
                exit_price = c
            if exit_price is not None:
                exit_price *= (1 - config.SLIPPAGE_PCT)
                cash = qty * exit_price * (1 - config.FEE_PCT)
                trades.append(exit_price / entry - 1 - 2 * config.FEE_PCT)
                qty = 0.0
        elif buys[i]:
            entry = c * (1 + config.SLIPPAGE_PCT)
            qty = cash * (1 - config.FEE_PCT) / entry
            cash = 0.0
        equity.append(cash + qty * c)
    return equity, trades


def fmt(ms):
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")


def report(name, candles, equity, trades):
    if not candles:
        return
    peak, max_dd = equity[0], 0.0
    for e in equity:
        peak = max(peak, e)
        max_dd = min(max_dd, (e - peak) / peak)
    buy_hold = candles[-1][4] / candles[0][4] - 1
    wins = sum(1 for t in trades if t > 0)
    print(f"\n=== {name} ===")
    print(f"Period:          {fmt(candles[0][0])}  ->  {fmt(candles[-1][0])}")
    print(f"Strategy return: {equity[-1] / equity[0] - 1:+.2%}")
    print(f"Buy & hold:      {buy_hold:+.2%}")
    print(f"Max drawdown:    {max_dd:.2%}")
    print(f"Trades:          {len(trades)}")
    if trades:
        print(f"Win rate:        {wins / len(trades):.1%}")


if __name__ == "__main__":
    candles = load_csv(csv_path())
    eq, tr = run_backtest(candles)
    report("FULL PERIOD", candles, eq, tr)

    part = candles[int(len(candles) * 0.7):]
    eq2, tr2 = run_backtest(part)
    report("OUT-OF-SAMPLE (last 30%)", part, eq2, tr2)
    print("\nIf the out-of-sample result is much worse than the full period, "
          "the strategy is probably overfit.")
