"""Demo trading bot (Binance Spot TESTNET). Long-only EMA crossover + RSI filter,
with stop-loss / take-profit managed by the bot. Stop with Ctrl+C."""
import csv
import json
import logging
import os
import time
from datetime import datetime, timezone

import config
from strategy import latest_signal
from test_connection import make_exchange

STATE_FILE = "state.json"
TRADE_LOG = "trades.csv"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[logging.FileHandler("bot.log"), logging.StreamHandler()],
)
log = logging.getLogger("bot")


def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"position": None, "trades_today": 0, "day": str(datetime.now(timezone.utc).date())}


def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def log_trade(side, price, amount, note=""):
    new = not os.path.exists(TRADE_LOG)
    with open(TRADE_LOG, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["time_utc", "side", "price", "amount", "note"])
        w.writerow([datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    side, price, amount, note])


def get_candles(ex):
    raw = ex.fetch_ohlcv(config.SYMBOL, config.TIMEFRAME, limit=300)
    return raw[:-1]  # drop the still-forming candle


def buy(ex, state, price):
    quote = config.SYMBOL.split("/")[1]
    free = ex.fetch_balance()["free"].get(quote, 0)
    cost = free * config.POSITION_FRACTION
    amount = float(ex.amount_to_precision(config.SYMBOL, cost / price))
    market = ex.market(config.SYMBOL)
    min_cost = (market.get("limits", {}).get("cost", {}) or {}).get("min") or 10
    if amount * price < min_cost:
        log.warning("Order too small (%.2f < min %.2f). Skipping buy.", amount * price, min_cost)
        return
    order = ex.create_market_buy_order(config.SYMBOL, amount)
    fill = order.get("average") or order.get("price") or price
    filled = order.get("filled") or amount
    state["position"] = {"entry": fill, "amount": filled}
    state["trades_today"] += 1
    log_trade("BUY", fill, filled, "signal")
    log.info("BUY %s @ %s", filled, fill)


def sell(ex, state, price, reason):
    base = config.SYMBOL.split("/")[0]
    held = ex.fetch_balance()["free"].get(base, 0)
    amount = min(state["position"]["amount"], held)
    amount = float(ex.amount_to_precision(config.SYMBOL, amount))
    if amount <= 0:
        log.warning("Nothing to sell. Clearing position.")
        state["position"] = None
        return
    order = ex.create_market_sell_order(config.SYMBOL, amount)
    fill = order.get("average") or order.get("price") or price
    pnl = fill / state["position"]["entry"] - 1
    log_trade("SELL", fill, amount, f"{reason} pnl={pnl:+.2%}")
    log.info("SELL %s @ %s (%s, %+.2f%%)", amount, fill, reason, pnl * 100)
    state["position"] = None
    state["trades_today"] += 1


def main():
    ex = make_exchange()
    ex.load_markets()
    state = load_state()
    log.info("Bot started on TESTNET | %s %s", config.SYMBOL, config.TIMEFRAME)

    while True:
        try:
            today = str(datetime.now(timezone.utc).date())
            if state["day"] != today:
                state["day"], state["trades_today"] = today, 0

            df = get_candles(ex)
            signal = latest_signal(df)
            price = ex.fetch_ticker(config.SYMBOL)["last"]
            pos = state["position"]

            if pos:
                stop = pos["entry"] * (1 - config.STOP_LOSS_PCT)
                tp = pos["entry"] * (1 + config.TAKE_PROFIT_PCT)
                if price <= stop:
                    sell(ex, state, price, "stop-loss")
                elif price >= tp:
                    sell(ex, state, price, "take-profit")
                elif signal == "sell":
                    sell(ex, state, price, "signal")
            elif signal == "buy" and state["trades_today"] < config.MAX_TRADES_PER_DAY:
                buy(ex, state, price)

            save_state(state)
            log.info("price=%s signal=%s in_position=%s", price, signal, bool(state["position"]))
        except KeyboardInterrupt:
            log.info("Stopped by user.")
            break
        except Exception as e:  # keep running through network hiccups
            log.error("Error: %s", e)
        time.sleep(config.CHECK_EVERY_SECONDS)


if __name__ == "__main__":
    main()
