"""Run this first: checks your testnet keys work and shows your demo balance."""
import ccxt
import config


def make_exchange():
    if not config.API_KEY or not config.API_SECRET:
        raise SystemExit("Missing keys. Copy .env.example to .env and fill in your testnet keys.")
    ex = ccxt.binance({
        "apiKey": config.API_KEY,
        "secret": config.API_SECRET,
        "enableRateLimit": True,
        "options": {"defaultType": "spot",
                    "adjustForTimeDifference": True,
                    "recvWindow": 60000},
    })
    ex.set_sandbox_mode(True)  # <- points to the Binance Spot TESTNET (fake money)
    return ex


if __name__ == "__main__":
    ex = make_exchange()
    ex.load_markets()
    print("Connected to Binance Spot TESTNET")
    print(f"{config.SYMBOL} price: {ex.fetch_ticker(config.SYMBOL)['last']}")
    bal = ex.fetch_balance()["total"]
    main = {k: bal.get(k, 0) for k in ("USDT", "BTC", "ETH", "BNB")}
    print("Demo balances (main coins):", main)
