import os
from dotenv import load_dotenv

load_dotenv()

# ---- Market ----
SYMBOL = "BTC/USDT"
TIMEFRAME = "1h"          # 1m, 5m, 15m, 1h, 4h, 1d
HISTORY_YEARS = 2

# ---- Strategy (EMA crossover + RSI filter, long-only spot) ----
FAST_EMA = 20
SLOW_EMA = 50
RSI_PERIOD = 14
RSI_MAX_ENTRY = 70        # don't open a new buy if RSI is above this

# ---- Risk ----
POSITION_FRACTION = 0.10  # use 10% of free USDT per trade
STOP_LOSS_PCT = 0.02      # exit if price falls 2% below entry
TAKE_PROFIT_PCT = 0.04    # exit if price rises 4% above entry
MAX_TRADES_PER_DAY = 6

# ---- Backtest realism ----
FEE_PCT = 0.001           # 0.1% per side
SLIPPAGE_PCT = 0.0005     # 0.05% per side
START_BALANCE = 1000.0

# ---- Bot loop ----
CHECK_EVERY_SECONDS = 60

# ---- Keys / exchanges ----
API_KEY = os.getenv("BINANCE_TESTNET_API_KEY", "")
API_SECRET = os.getenv("BINANCE_TESTNET_API_SECRET", "")
DATA_EXCHANGE = os.getenv("DATA_EXCHANGE", "binance")
