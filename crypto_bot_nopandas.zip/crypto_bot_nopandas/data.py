"""Download real historical candles (public data, no API key needed)."""
import csv
import time
import ccxt
import config


def fetch_history(symbol=config.SYMBOL, timeframe=config.TIMEFRAME,
                  years=config.HISTORY_YEARS):
    ex = getattr(ccxt, config.DATA_EXCHANGE)({"enableRateLimit": True})
    tf_ms = ex.parse_timeframe(timeframe) * 1000
    since = ex.milliseconds() - int(years * 365 * 24 * 3600 * 1000)
    rows = []
    while True:
        batch = ex.fetch_ohlcv(symbol, timeframe, since=since, limit=1000)
        if not batch:
            break
        rows += batch
        since = batch[-1][0] + tf_ms
        print(f"  fetched {len(rows)} candles...", end="\r")
        if len(batch) < 2 or since >= ex.milliseconds():
            break
        time.sleep(ex.rateLimit / 1000)
    seen, unique = set(), []
    for r in rows:
        if r[0] not in seen:
            seen.add(r[0])
            unique.append(r)
    return unique


def csv_path(symbol=config.SYMBOL, timeframe=config.TIMEFRAME):
    return f"data/{symbol.replace('/', '')}_{timeframe}.csv"


def save_csv(candles, path):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["time", "open", "high", "low", "close", "volume"])
        w.writerows(candles)


def load_csv(path):
    with open(path, newline="") as f:
        reader = csv.reader(f)
        next(reader)
        return [[int(r[0])] + [float(x) for x in r[1:]] for r in reader]


if __name__ == "__main__":
    print(f"Downloading {config.HISTORY_YEARS}y of {config.SYMBOL} {config.TIMEFRAME} "
          f"from {config.DATA_EXCHANGE}...")
    candles = fetch_history()
    path = csv_path()
    save_csv(candles, path)
    print(f"\nSaved {len(candles)} candles to {path}")
